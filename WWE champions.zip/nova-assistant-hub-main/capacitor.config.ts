
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.def79c61aa454005b6f95501bfa1664c',
  appName: 'nova-assistant-hub',
  webDir: 'dist',
  server: {
    url: 'https://def79c61-aa45-4005-b6f9-5501bfa1664c.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
    },
  },
};

export default config;
