
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
  },
  plugins: [
    react(), // Use the default React plugin without the invalid babel property
    mode === 'development' &&
    componentTagger(),
  ].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
      // Add react-native aliases
      'react-native': 'react-native-web'
    },
    extensions: ['.web.js', '.web.jsx', '.web.ts', '.web.tsx', '.js', '.jsx', '.ts', '.tsx', '.json']
  },
  // Build configuration optimized for mobile
  build: {
    outDir: 'dist',
    minify: 'terser',
    sourcemap: true,
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom', 'react-router-dom'],
          ui: [
            '@radix-ui/react-dialog', 
            '@radix-ui/react-separator', 
            '@radix-ui/react-select',
            '@radix-ui/react-tabs'
          ]
        }
      }
    }
  },
  // Define global variables for React Native Web
  define: {
    // This helps compatibility with React Native modules
    __DEV__: JSON.stringify(process.env.NODE_ENV === 'development')
  }
}));
