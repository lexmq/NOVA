
import React, { createContext, useState, useContext, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";

interface User {
  id: string;
  firstName: string;
  middleName?: string;
  lastName?: string;
  email: string;
  phone?: string;
  name: string; // Full name (computed from firstName, middleName, lastName)
  profileImage?: string; // Added profile image
}

interface AuthContextType {
  user: User | null;
  isLoggedIn: boolean;
  login: (email: string, password: string, userData?: Partial<User>) => void;
  logout: () => void;
  updateProfile: (userData: Partial<User>) => void;
  uploadProfileImage: (imageFile: File) => void; // New method for profile image
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [user, setUser] = useState<User | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Check if user is already logged in on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
        setIsLoggedIn(true);
      } catch (error) {
        console.error("Error parsing stored user", error);
        localStorage.removeItem("user");
      }
    }
  }, []);

  // Redirect to login if not authenticated
  useEffect(() => {
    const publicPaths = ["/settings/account"];
    
    if (!isLoggedIn && !publicPaths.includes(location.pathname)) {
      navigate("/settings/account");
    }
  }, [isLoggedIn, location.pathname, navigate]);

  const generateFullName = (userData: Partial<User>): string => {
    const parts = [];
    if (userData.firstName) parts.push(userData.firstName);
    if (userData.middleName) parts.push(userData.middleName);
    if (userData.lastName) parts.push(userData.lastName);
    
    return parts.length > 0 ? parts.join(" ") : (userData.email ? userData.email.split("@")[0] : "User");
  };

  const login = (email: string, password: string, userData?: Partial<User>) => {
    // In a real app, you'd validate with a backend
    const firstName = userData?.firstName || email.split("@")[0];
    
    const newUser = {
      id: Math.random().toString(36).substring(2),
      firstName: firstName,
      middleName: userData?.middleName || "",
      lastName: userData?.lastName || "",
      email: email,
      phone: userData?.phone || "",
      name: userData ? generateFullName(userData) : firstName,
      profileImage: userData?.profileImage || ""
    };
    
    setUser(newUser);
    setIsLoggedIn(true);
    localStorage.setItem("user", JSON.stringify(newUser));
  };

  const updateProfile = (userData: Partial<User>) => {
    if (!user) return;

    const updatedUser = {
      ...user,
      ...userData,
      // Always regenerate the full name when updating
      name: generateFullName({ ...user, ...userData })
    };
    
    setUser(updatedUser);
    localStorage.setItem("user", JSON.stringify(updatedUser));
  };

  // New method to handle profile image upload
  const uploadProfileImage = (imageFile: File) => {
    if (!user) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      const updatedUser = {
        ...user,
        profileImage: base64String
      };
      
      setUser(updatedUser);
      localStorage.setItem("user", JSON.stringify(updatedUser));
    };
    reader.readAsDataURL(imageFile);
  };

  const logout = () => {
    setUser(null);
    setIsLoggedIn(false);
    localStorage.removeItem("user");
    navigate("/settings/account");
  };

  const value = {
    user,
    isLoggedIn,
    login,
    logout,
    updateProfile,
    uploadProfileImage
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
