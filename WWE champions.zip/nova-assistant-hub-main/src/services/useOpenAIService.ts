
import { useState } from "react";

// Updated API key
const API_KEY = "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";

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export const useOpenAIService = () => {
  const [isLoading, setIsLoading] = useState(false);

  const generateChatResponse = async (messages: ChatMessage[]): Promise<string> => {
    setIsLoading(true);
    
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages,
          max_tokens: 500,
          temperature: 0.7,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        console.error("OpenAI API error:", errorData || response.statusText);
        throw new Error(`API request failed: ${response.status}`);
      }

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (error) {
      console.error('Error fetching from OpenAI:', error);
      return "I'm sorry, I couldn't process your request. Please try again later.";
    } finally {
      setIsLoading(false);
    }
  };

  return { generateChatResponse, isLoading };
};
