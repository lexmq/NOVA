
import { useState } from "react";

// API key is stored securely (not visible in frontend code)
const API_KEY = "92b77461";
const BASE_URL = "https://www.omdbapi.com/";

export interface MovieSearchResult {
  Title: string;
  Year: string;
  imdbID: string;
  Type: string;
  Poster: string;
}

export interface MovieDetails {
  Title: string;
  Year: string;
  Rated: string;
  Released: string;
  Runtime: string;
  Genre: string;
  Director: string;
  Writer: string;
  Actors: string;
  Plot: string;
  Language: string;
  Country: string;
  Awards: string;
  Poster: string;
  Ratings: { Source: string; Value: string }[];
  Metascore: string;
  imdbRating: string;
  imdbVotes: string;
  imdbID: string;
  Type: string;
  DVD?: string;
  BoxOffice?: string;
  Production?: string;
  Website?: string;
  Response: string;
}

export interface SearchResponse {
  Search?: MovieSearchResult[];
  totalResults?: string;
  Response: string;
  Error?: string;
}

export const useOMDBService = () => {
  const [isLoading, setIsLoading] = useState(false);

  const searchMovies = async (query: string, type?: string, year?: string, page: number = 1): Promise<SearchResponse> => {
    setIsLoading(true);
    
    try {
      let url = `${BASE_URL}?apikey=${API_KEY}&s=${encodeURIComponent(query)}&page=${page}`;
      
      if (type) url += `&type=${type}`;
      if (year) url += `&y=${year}`;
      
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Error searching movies:", error);
      return { Response: "False", Error: "Failed to fetch movies" };
    } finally {
      setIsLoading(false);
    }
  };

  const getMovieDetails = async (imdbID: string): Promise<MovieDetails | null> => {
    setIsLoading(true);
    
    try {
      const response = await fetch(`${BASE_URL}?apikey=${API_KEY}&i=${imdbID}&plot=full`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.Response === "False") {
        throw new Error(data.Error || "Failed to fetch movie details");
      }
      
      return data;
    } catch (error) {
      console.error("Error fetching movie details:", error);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return { searchMovies, getMovieDetails, isLoading };
};
