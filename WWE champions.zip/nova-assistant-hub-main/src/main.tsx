
import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'

// Only run this code in web environments
if (typeof document !== 'undefined') {
  const container = document.getElementById("root");
  if (container) {
    createRoot(container).render(<App />);
  }
}

// Export App for Expo/React Native entry point
export default App;
