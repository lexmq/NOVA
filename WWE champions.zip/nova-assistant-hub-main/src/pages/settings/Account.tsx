import React, { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/AuthContext";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User, Upload, Camera, Edit, Save, X, LogOut } from "lucide-react";

// Login form schema
const loginSchema = z.object({
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  password: z.string().min(6, {
    message: "Password must be at least 6 characters.",
  }),
});

// Signup form schema with profile picture
const signupSchema = z.object({
  firstName: z.string().min(2, {
    message: "First name must be at least 2 characters.",
  }),
  middleName: z.string().optional(),
  lastName: z.string().optional(),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  phone: z.string().optional(),
  password: z.string().min(6, {
    message: "Password must be at least 6 characters.",
  }),
  confirmPassword: z.string().min(6, {
    message: "Password must be at least 6 characters.",
  }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

// Profile edit schema
const profileEditSchema = z.object({
  firstName: z.string().min(2, {
    message: "First name must be at least 2 characters.",
  }),
  middleName: z.string().optional(),
  lastName: z.string().optional(),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  phone: z.string().optional(),
});

// Login form types
type LoginFormValues = z.infer<typeof loginSchema>;
// Signup form types
type SignupFormValues = z.infer<typeof signupSchema>;
// Profile edit types
type ProfileEditValues = z.infer<typeof profileEditSchema>;

export default function Account() {
  const { user, login, uploadProfileImage, updateProfile, isLoggedIn, logout } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [mode, setMode] = useState<"login" | "signup">("login");
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  // Default values for login form
  const loginDefaultValues: Partial<LoginFormValues> = {
    email: "",
    password: "",
  };

  // Default values for signup form
  const signupDefaultValues: Partial<SignupFormValues> = {
    firstName: "",
    middleName: "",
    lastName: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  };

  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: loginDefaultValues,
  });

  // Signup form
  const signupForm = useForm<SignupFormValues>({
    resolver: zodResolver(signupSchema),
    defaultValues: signupDefaultValues,
  });

  // Profile edit form
  const profileEditForm = useForm<ProfileEditValues>({
    resolver: zodResolver(profileEditSchema),
    defaultValues: {
      firstName: user?.firstName || "",
      middleName: user?.middleName || "",
      lastName: user?.lastName || "",
      email: user?.email || "",
      phone: user?.phone || "",
    }
  });

  // Update profile edit form when user data changes
  useEffect(() => {
    if (user && isEditing) {
      profileEditForm.reset({
        firstName: user.firstName || "",
        middleName: user.middleName || "",
        lastName: user.lastName || "",
        email: user.email || "",
        phone: user.phone || "",
      });
      setProfileImage(user.profileImage || null);
    }
  }, [user, isEditing, profileEditForm]);

  // Handle profile image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      processImageFile(file);
    }
  };

  const processImageFile = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      setProfileImage(reader.result as string);
      toast.success("Profile image uploaded successfully");
    };
    reader.onerror = () => {
      toast.error("Failed to read image file");
    };
    reader.readAsDataURL(file);
  };

  // Handle drag and drop functionality
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };
  
  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('image/')) {
        processImageFile(file);
      } else {
        toast.error("Please upload an image file");
      }
    }
  };

  // Trigger file input click
  const triggerFileUpload = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  // Login handler
  const onLoginSubmit = async (data: LoginFormValues) => {
    try {
      login(data.email, data.password);
      toast.success("Login successful");
      navigate("/");
    } catch (error) {
      toast.error("Login failed. Please check your credentials.");
    }
  };

  // Updated signup handler to include profile image
  const onSignupSubmit = async (data: SignupFormValues) => {
    try {
      // Check if passwords match
      if (data.password !== data.confirmPassword) {
        toast.error("Passwords don't match");
        return;
      }

      // Create user object with profile information
      const userData = {
        firstName: data.firstName,
        middleName: data.middleName,
        lastName: data.lastName,
        email: data.email,
        phone: data.phone,
        profileImage: profileImage || "",
      };

      // Login with user data
      login(data.email, data.password, userData);
      toast.success("Account created successfully");
      navigate("/");
    } catch (error) {
      toast.error("Signup failed. Please try again.");
    }
  };

  // Profile edit handler
  const onProfileEditSubmit = async (data: ProfileEditValues) => {
    try {
      // Update profile information
      const updatedData = {
        ...data,
        profileImage: profileImage || user?.profileImage,
      };
      
      updateProfile(updatedData);
      setIsEditing(false);
      toast.success("Profile updated successfully");
    } catch (error) {
      toast.error("Failed to update profile. Please try again.");
    }
  };
  
  // Toggle edit mode
  const toggleEditMode = () => {
    if (isEditing) {
      setIsEditing(false);
    } else {
      setIsEditing(true);
      if (user) {
        profileEditForm.reset({
          firstName: user.firstName || "",
          middleName: user.middleName || "",
          lastName: user.lastName || "",
          email: user.email || "",
          phone: user.phone || "",
        });
        setProfileImage(user.profileImage || null);
      }
    }
  };

  // If the user is already logged in, show profile
  if (isLoggedIn && user) {
    return (
      <div className="py-8 px-4 space-y-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Account Settings</h1>
          {!isEditing ? (
            <div className="flex gap-2">
              <Button onClick={toggleEditMode} className="flex items-center gap-2">
                <Edit size={18} />
                Edit Profile
              </Button>
              <Button 
                variant="destructive" 
                onClick={logout} 
                className="flex items-center gap-2"
              >
                <LogOut size={18} />
                Logout
              </Button>
            </div>
          ) : (
            <div className="flex gap-2">
              <Button variant="ghost" onClick={toggleEditMode} className="flex items-center gap-2">
                <X size={18} />
                Cancel
              </Button>
              <Button onClick={profileEditForm.handleSubmit(onProfileEditSubmit)} className="flex items-center gap-2">
                <Save size={18} />
                Save Changes
              </Button>
            </div>
          )}
        </div>

        {!isEditing ? (
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <Avatar className="h-20 w-20">
                  {user.profileImage ? (
                    <AvatarImage src={user.profileImage} />
                  ) : (
                    <AvatarFallback className="bg-primary text-primary-foreground text-xl">
                      {user.firstName?.charAt(0) || user.email?.charAt(0)}
                    </AvatarFallback>
                  )}
                </Avatar>
                <div>
                  <h2 className="text-xl font-bold">{user.name}</h2>
                  <p className="text-muted-foreground">{user.email}</p>
                  {user.phone && <p className="text-muted-foreground">{user.phone}</p>}
                  <p className="text-sm text-primary mt-1">User ID: {user.id}</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <Form {...profileEditForm}>
            <form onSubmit={profileEditForm.handleSubmit(onProfileEditSubmit)} className="space-y-6">
              <div className="flex justify-center mb-4">
                <div 
                  className={`relative cursor-pointer ${isDragOver ? "ring-2 ring-primary" : ""}`}
                  onClick={triggerFileUpload}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                >
                  <Avatar className="h-24 w-24">
                    {profileImage || user.profileImage ? (
                      <AvatarImage src={profileImage || user.profileImage || ""} />
                    ) : (
                      <AvatarFallback className="bg-primary flex flex-col items-center justify-center">
                        <Camera className="h-8 w-8" />
                        <span className="text-[8px] mt-1">Upload</span>
                      </AvatarFallback>
                    )}
                  </Avatar>
                  <div className="absolute bottom-0 right-0 bg-primary text-primary-foreground rounded-full p-1">
                    <Upload className="h-4 w-4" />
                  </div>
                  <Input
                    ref={fileInputRef}
                    id="profile-image"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleImageUpload}
                  />
                </div>
              </div>
              
              <div className="text-center text-xs text-muted-foreground mb-2">
                Click to upload or drag & drop your profile image
              </div>
              
              <FormField
                control={profileEditForm.control}
                name="firstName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your first name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={profileEditForm.control}
                  name="middleName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Middle Name (Optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="Middle name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={profileEditForm.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last Name (Optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="Last name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={profileEditForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={profileEditForm.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Phone number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </form>
          </Form>
        )}
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-md py-10 space-y-6">
      <div className="flex justify-center mb-8">
        <img 
          src="/lovable-uploads/f312cbe9-b94e-4d97-962b-e3bf9c505c0f.png" 
          alt="Nova Virtual Assistant" 
          className="w-40 h-40" 
        />
      </div>

      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Welcome to Nova</h1>
        <p className="text-muted-foreground">
          Your personal virtual assistant
        </p>
      </div>

      <div className="flex gap-2 mb-8">
        <Button 
          variant={mode === "login" ? "default" : "outline"} 
          className="flex-1"
          onClick={() => setMode("login")}
        >
          Login
        </Button>
        <Button 
          variant={mode === "signup" ? "default" : "outline"} 
          className="flex-1"
          onClick={() => setMode("signup")}
        >
          Signup
        </Button>
      </div>

      {mode === "login" ? (
        // Login Form
        <Form {...loginForm}>
          <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
            <FormField
              control={loginForm.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Login ID (Email)</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter your email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={loginForm.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="Enter your password" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full">
              Login
            </Button>
          </form>
        </Form>
      ) : (
        // Enhanced Signup Form with image upload
        <Form {...signupForm}>
          <form onSubmit={signupForm.handleSubmit(onSignupSubmit)} className="space-y-4">
            <div className="flex justify-center mb-4">
              <div 
                className={`relative cursor-pointer ${isDragOver ? "ring-2 ring-primary" : ""}`}
                onClick={triggerFileUpload}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                <Avatar className="h-24 w-24">
                  {profileImage ? (
                    <AvatarImage src={profileImage} />
                  ) : (
                    <AvatarFallback className="bg-primary flex flex-col items-center justify-center">
                      <Camera className="h-8 w-8" />
                      <span className="text-[8px] mt-1">Upload</span>
                    </AvatarFallback>
                  )}
                </Avatar>
                <div className="absolute bottom-0 right-0 bg-primary text-primary-foreground rounded-full p-1">
                  <Upload className="h-4 w-4" />
                </div>
                <Input
                  ref={fileInputRef}
                  id="profile-image"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageUpload}
                />
              </div>
            </div>
            
            <div className="text-center text-xs text-muted-foreground mb-2">
              Click to upload or drag & drop your profile image
            </div>
            
            <FormField
              control={signupForm.control}
              name="firstName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>First Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter your first name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={signupForm.control}
                name="middleName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Middle Name (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Middle name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={signupForm.control}
                name="lastName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Last Name (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Last name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={signupForm.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter your email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={signupForm.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="Phone number" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={signupForm.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="Create a password" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={signupForm.control}
              name="confirmPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Confirm Password</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="Confirm your password" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button type="submit" className="w-full">
              Create Account
            </Button>
          </form>
        </Form>
      )}
    </div>
  );
}
