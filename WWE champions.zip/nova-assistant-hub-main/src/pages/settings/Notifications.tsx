
import React, { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

interface NotificationSetting {
  id: string;
  title: string;
  description: string;
  enabled: boolean;
}

const Notifications = () => {
  const [settings, setSettings] = useState<NotificationSetting[]>([
    {
      id: "all",
      title: "Enable Notifications",
      description: "Master toggle for all notifications",
      enabled: true,
    },
    {
      id: "chat",
      title: "Chat Messages",
      description: "Notifications for new chat messages",
      enabled: true,
    },
    {
      id: "reminders",
      title: "Reminders",
      description: "Notifications for tasks and reminders",
      enabled: true,
    },
    {
      id: "updates",
      title: "App Updates",
      description: "Notifications about new features and updates",
      enabled: false,
    },
  ]);

  const toggleSetting = (id: string) => {
    setSettings(prev => {
      const updated = prev.map(setting => {
        if (setting.id === id) {
          return { ...setting, enabled: !setting.enabled };
        }
        // If master toggle (all) is toggled, update all settings
        if (id === "all" && setting.id !== "all") {
          return { ...setting, enabled: !prev.find(s => s.id === "all")!.enabled };
        }
        return setting;
      });
      
      // Show toast notification
      const setting = prev.find(s => s.id === id);
      if (setting) {
        const newState = !setting.enabled;
        toast.success(`${setting.title} ${newState ? 'enabled' : 'disabled'}`);
      }
      
      return updated;
    });
  };

  const isAllEnabled = settings.find(s => s.id === "all")?.enabled;

  return (
    <div className="space-y-6 p-2">
      <div className="flex items-center space-x-2">
        <Link to="/settings">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Notifications</h1>
      </div>

      <Separator />

      <div className="space-y-4">
        {settings.map((setting) => (
          <div 
            key={setting.id}
            className="glass-morphism rounded-lg p-4 flex items-center justify-between"
          >
            <div>
              <h3 className="font-medium text-white">{setting.title}</h3>
              <p className="text-sm text-gray-400">{setting.description}</p>
            </div>
            <Switch 
              checked={setting.enabled} 
              onCheckedChange={() => toggleSetting(setting.id)}
              disabled={setting.id !== "all" && !isAllEnabled}
            />
          </div>
        ))}
      </div>
      
      <div className="pt-4">
        <Button 
          variant="outline" 
          className="w-full"
          onClick={() => toast.success("Test notification sent!")}
        >
          Send Test Notification
        </Button>
      </div>
    </div>
  );
};

export default Notifications;
