
import React from "react";
import { ArrowLeft, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { toast } from "sonner";

interface FAQItem {
  question: string;
  answer: string;
}

const faqs: FAQItem[] = [
  {
    question: "What is Nova Assistant?",
    answer: "Nova is an AI-powered virtual assistant that helps you with various tasks such as managing to-dos, translating languages, generating images, and more."
  },
  {
    question: "How do I use voice commands?",
    answer: "On the home screen, tap the microphone button and speak your command clearly. Nova can perform tasks like opening apps or answering questions."
  },
  {
    question: "Is my data secure?",
    answer: "Your privacy is important to us. We use encryption to protect your data and do not share it with third parties without your permission."
  },
  {
    question: "How do I create an account?",
    answer: "Go to Settings > Account and choose to sign up with either your email address or phone number."
  },
  {
    question: "Can I use Nova offline?",
    answer: "Some basic features work offline, but most of Nova's capabilities require an internet connection to communicate with our servers."
  }
];

const Help = () => {
  const [openItems, setOpenItems] = React.useState<Record<number, boolean>>({});

  const toggleItem = (index: number) => {
    setOpenItems(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  const handleContactSupport = () => {
    toast.success("Support ticket created! We'll get back to you soon.");
  };

  return (
    <div className="space-y-6 p-2 pb-20">
      <div className="flex items-center space-x-2">
        <Link to="/settings">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Help & Support</h1>
      </div>

      <Separator />

      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Frequently Asked Questions</h2>
        
        {faqs.map((faq, index) => (
          <Collapsible 
            key={index}
            open={openItems[index]}
            onOpenChange={() => toggleItem(index)}
            className="glass-morphism rounded-lg overflow-hidden"
          >
            <CollapsibleTrigger className="w-full p-4 flex justify-between items-center text-left">
              <span className="font-medium">{faq.question}</span>
              <span className="text-xl">{openItems[index] ? '−' : '+'}</span>
            </CollapsibleTrigger>
            <CollapsibleContent className="p-4 pt-0 text-gray-300 border-t border-gray-800">
              {faq.answer}
            </CollapsibleContent>
          </Collapsible>
        ))}
      </div>

      <div className="space-y-4 pt-4">
        <h2 className="text-xl font-semibold">Contact Us</h2>
        
        <div className="glass-morphism rounded-lg p-4 space-y-4">
          <p className="text-gray-300">
            Need more help? Our support team is ready to assist you.
          </p>
          
          <Button 
            className="w-full"
            onClick={handleContactSupport}
          >
            Contact Support
          </Button>
        </div>
        
        <div className="glass-morphism rounded-lg p-4">
          <h3 className="font-medium mb-2">Documentation</h3>
          <a 
            href="#" 
            className="flex items-center text-primary hover:underline"
            onClick={(e) => {
              e.preventDefault();
              toast.info("Documentation will be available soon");
            }}
          >
            View user guide <ExternalLink className="ml-1 h-4 w-4" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default Help;
