
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { User, Bell, Moon, HelpCircle, ChevronRight } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

interface SettingItemProps {
  icon: React.ReactNode;
  title: string;
  to?: string;
  onClick?: () => void;
  rightElement?: React.ReactNode;
}

const SettingItem = ({ icon, title, to, onClick, rightElement }: SettingItemProps) => {
  const Content = () => (
    <div className="glass-morphism rounded-lg p-4 flex items-center justify-between">
      <div className="flex items-center">
        <div className="bg-primary/10 rounded-full p-3 mr-4">
          {icon}
        </div>
        <div>
          <h3 className="font-medium text-white">{title}</h3>
        </div>
      </div>
      {rightElement || <ChevronRight className="w-5 h-5 text-gray-400" />}
    </div>
  );

  if (to) {
    return (
      <Link to={to}>
        <Content />
      </Link>
    );
  }

  return (
    <button className="w-full text-left" onClick={onClick}>
      <Content />
    </button>
  );
};

const Settings = () => {
  const [darkMode, setDarkMode] = useState(true);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    toast.success(`${darkMode ? 'Light' : 'Dark'} mode enabled`);
  };

  return (
    <div className="space-y-6 p-2">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-gray-400">Customize Nova Assistant</p>
      </div>
      
      <Separator />
      
      <div className="space-y-4">
        <SettingItem 
          icon={<User className="w-6 h-6 text-primary" />}
          title="Account"
          to="/settings/account"
        />
        
        <SettingItem 
          icon={<Bell className="w-6 h-6 text-primary" />}
          title="Notifications"
          to="/settings/notifications"
        />
        
        <SettingItem 
          icon={<Moon className="w-6 h-6 text-primary" />}
          title="Dark Mode"
          onClick={toggleDarkMode}
          rightElement={
            <Switch 
              checked={darkMode} 
              onCheckedChange={toggleDarkMode}
            />
          }
        />
        
        <SettingItem 
          icon={<HelpCircle className="w-6 h-6 text-primary" />}
          title="Help & Support"
          to="/settings/help"
        />
      </div>
    </div>
  );
};

export default Settings;
