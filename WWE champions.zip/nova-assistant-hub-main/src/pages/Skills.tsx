
import React from "react";
import { Link } from "react-router-dom";
import { 
  Languages, Paintbrush, CalendarCheck, Film, 
  ChevronRight, Smartphone
} from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface SkillCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  to: string;
}

const SkillCard = ({ icon, title, description, to }: SkillCardProps) => {
  return (
    <Link 
      to={to}
      className="glass-morphism rounded-lg p-4 flex items-center justify-between"
    >
      <div className="flex items-center">
        <div className="bg-primary/10 rounded-full p-3 mr-4">
          {icon}
        </div>
        <div>
          <h3 className="font-medium text-white">{title}</h3>
          <p className="text-sm text-gray-400">{description}</p>
        </div>
      </div>
      <ChevronRight className="w-5 h-5 text-gray-400" />
    </Link>
  );
};

const Skills = () => {
  const skills = [
    {
      icon: <Languages className="w-6 h-6 text-primary" />,
      title: "Language Translator",
      description: "Translate text between multiple languages",
      to: "/skills/translator"
    },
    {
      icon: <Paintbrush className="w-6 h-6 text-primary" />,
      title: "Creative AI",
      description: "Generate images from text descriptions",
      to: "/skills/creative-ai"
    },
    {
      icon: <CalendarCheck className="w-6 h-6 text-primary" />,
      title: "To-Do List",
      description: "Manage your tasks and reminders",
      to: "/skills/todo"
    },
    {
      icon: <Film className="w-6 h-6 text-primary" />,
      title: "Movies & Entertainment",
      description: "Find movies and TV shows to watch",
      to: "/skills/entertainment"
    }
  ];

  const showMobileInstructions = () => {
    toast.success("Mobile app installation instructions shown");
  };

  return (
    <div className="space-y-6 p-2">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Skills</h1>
          <p className="text-gray-400">Explore Nova's capabilities</p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={showMobileInstructions}
            >
              <Smartphone className="h-4 w-4" />
              Mobile App
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Nova Assistant Mobile App</DialogTitle>
              <DialogDescription>
                Use Nova Assistant on your mobile device
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <h3 className="font-medium">Use with Expo Go:</h3>
                <p className="text-sm text-gray-500">
                  Nova Assistant can be run on your mobile device using the Expo Go app:
                </p>
                <ol className="list-decimal list-inside text-sm text-gray-500 space-y-2">
                  <li>Download the Expo Go app from the App Store or Google Play Store</li>
                  <li>Scan the QR code shown when running the app with <code>npx expo start</code></li>
                  <li>Enjoy Nova Assistant on your mobile device!</li>
                </ol>
              </div>
              
              <div className="space-y-2 mt-4">
                <h3 className="font-medium">Alternative: Install as PWA:</h3>
                <p className="text-sm text-gray-500">
                  You can also install Nova Assistant as a Progressive Web App:
                </p>
                <h4 className="font-medium text-sm mt-3">On iOS:</h4>
                <ol className="list-decimal list-inside text-sm text-gray-500 space-y-2">
                  <li>Open this site in Safari</li>
                  <li>Tap the Share button</li>
                  <li>Scroll down and tap "Add to Home Screen"</li>
                  <li>Tap "Add" to confirm</li>
                </ol>
                
                <h4 className="font-medium text-sm mt-3">On Android:</h4>
                <ol className="list-decimal list-inside text-sm text-gray-500 space-y-2">
                  <li>Open this site in Chrome</li>
                  <li>Tap the three-dot menu</li>
                  <li>Select "Add to Home screen"</li>
                  <li>Tap "Add" to confirm</li>
                </ol>
              </div>
              
              <div className="space-y-2">
                <h3 className="font-medium">Benefits:</h3>
                <ul className="list-disc list-inside text-sm text-gray-500 space-y-1">
                  <li>Full mobile experience</li>
                  <li>Access to native features</li>
                  <li>Better performance</li>
                  <li>Offline capabilities</li>
                </ul>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      
      <Separator />
      
      <div className="space-y-4">
        {skills.map((skill, index) => (
          <SkillCard 
            key={index}
            icon={skill.icon}
            title={skill.title}
            description={skill.description}
            to={skill.to}
          />
        ))}
      </div>
    </div>
  );
};

export default Skills;
