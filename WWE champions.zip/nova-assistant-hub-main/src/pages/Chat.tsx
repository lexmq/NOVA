
import React, { useState, useEffect, useRef } from "react";
import { SendIcon, Mic, StopCircle } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { useOpenAIService, ChatMessage as OpenAIChatMessage } from "@/services/useOpenAIService";

interface Message {
  id: string;
  content: string;
  sender: "user" | "assistant";
  timestamp: Date;
}

const Chat = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      content: "Hi, I'm Nova. How can I help you today?",
      sender: "assistant",
      timestamp: new Date(),
    },
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { generateChatResponse, isLoading: isOpenAILoading } = useOpenAIService();

  useEffect(() => {
    // Initialize speech recognition
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognitionAPI) {
        const recognitionInstance = new SpeechRecognitionAPI();
        
        recognitionInstance.continuous = false;
        recognitionInstance.interimResults = false;
        recognitionInstance.lang = 'en-US';
        
        recognitionInstance.onresult = (event) => {
          const current = event.resultIndex;
          const transcriptText = event.results[current][0].transcript;
          
          // Check if the command is "stop"
          if (transcriptText.toLowerCase().includes('stop')) {
            // Stop any ongoing process
            setIsProcessing(false);
            
            // Cancel speech synthesis if it's active
            if ('speechSynthesis' in window) {
              window.speechSynthesis.cancel();
            }
            
            toast.info("Stopped current action");
            return;
          }
          
          setInputMessage(transcriptText);
        };
        
        recognitionInstance.onend = () => {
          setIsListening(false);
        };
        
        recognitionInstance.onerror = (event) => {
          console.error('Speech recognition error', event.error);
          setIsListening(false);
          toast.error("Couldn't understand. Please try again.");
        };
        
        setRecognition(recognitionInstance);
      }
    }
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const toggleListening = () => {
    if (!recognition) {
      toast.error("Speech recognition is not supported in this browser");
      return;
    }
    
    if (isListening) {
      recognition.stop();
    } else {
      setIsListening(true);
      recognition.start();
    }
  };

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1;
      utterance.pitch = 0.9; // Lower pitch for male voice
      utterance.volume = 1;
      
      // Try to set a male voice if available
      const voices = window.speechSynthesis.getVoices();
      const maleVoice = voices.find(voice => 
        voice.name.toLowerCase().includes('male') || 
        voice.name.includes('David') || 
        voice.name.includes('James') || 
        voice.name.includes('Thomas') ||
        voice.name.includes('Daniel') ||
        voice.name.includes('Google US English Male')
      );
      
      if (maleVoice) {
        utterance.voice = maleVoice;
      }
      
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage,
      sender: "user",
      timestamp: new Date(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInputMessage("");
    setIsProcessing(true);
    
    try {
      // Check for stop command
      if (userMessage.content.toLowerCase().includes('stop')) {
        // Cancel any ongoing operations
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
        }
        setIsProcessing(false);
        
        const stopMessage: Message = {
          id: Date.now().toString(),
          content: "I've stopped the current operation.",
          sender: "assistant",
          timestamp: new Date(),
        };
        
        setMessages(prev => [...prev, stopMessage]);
        return;
      }
      
      // Use OpenAI API directly with the pre-configured key
      const formatMessagesForAPI = () => {
        return [
          {
            role: 'system' as const,
            content: 'You are Nova, a friendly and helpful AI assistant. Provide concise and accurate responses.'
          },
          ...messages.map(msg => ({
            role: msg.sender === 'user' ? 'user' as const : 'assistant' as const,
            content: msg.content
          })),
          { role: 'user' as const, content: userMessage.content }
        ] as OpenAIChatMessage[];
      };

      const aiResponse = await generateChatResponse(formatMessagesForAPI());
      
      const responseMessage: Message = {
        id: Date.now().toString(),
        content: aiResponse,
        sender: "assistant",
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, responseMessage]);
      speak(aiResponse);
    } catch (error) {
      console.error('Error processing message:', error);
      toast.error("Failed to get a response. Please try again later.");
      
      const errorMessage: Message = {
        id: Date.now().toString(),
        content: "I'm sorry, I couldn't process your request right now. Please try again later.",
        sender: "assistant",
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Chat with Nova</h1>
      </div>
      
      {/* Message display area - takes all available space except input area */}
      <div className="flex-1 mb-16 overflow-hidden">
        <ScrollArea className="h-[calc(100vh-220px)]">
          <div className="space-y-4 px-1">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${
                  message.sender === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[80%] rounded-lg px-4 py-2 ${
                    message.sender === "user"
                      ? "bg-primary text-white"
                      : "glass-morphism text-gray-200"
                  }`}
                >
                  <p>{message.content}</p>
                  <p className="text-xs opacity-50 mt-1">
                    {message.timestamp.toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      </div>
      
      {/* Fixed input area at the bottom */}
      <div className="fixed bottom-16 left-0 right-0 px-4 z-10">
        <div className="flex items-center space-x-2 neo-blur rounded-xl p-2">
          <Button
            size="icon"
            variant="ghost"
            onClick={toggleListening}
            className={`${isListening ? "text-red-500" : "text-gray-400"}`}
          >
            {isListening ? <StopCircle /> : <Mic />}
          </Button>
          <Input
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message..."
            className="flex-grow bg-transparent border-gray-700"
            disabled={isProcessing}
          />
          <Button
            size="icon"
            onClick={handleSendMessage}
            disabled={!inputMessage.trim() || isProcessing}
          >
            <SendIcon />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Chat;
