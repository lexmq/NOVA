
import React, { useState, useEffect } from "react";
import { ArrowLeft, Plus, Calendar, Trash2, Check } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";

interface Task {
  id: string;
  title: string;
  completed: boolean;
  date: Date;
}

const Todo = () => {
  const [tasks, setTasks] = useState<Task[]>(() => {
    const savedTasks = localStorage.getItem("nova-tasks");
    if (savedTasks) {
      try {
        const parsedTasks = JSON.parse(savedTasks);
        return parsedTasks.map((task: any) => ({
          ...task,
          date: new Date(task.date)
        }));
      } catch (e) {
        console.error("Error parsing saved tasks:", e);
        return [];
      }
    }
    return [];
  });

  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [completionRate, setCompletionRate] = useState(0);

  useEffect(() => {
    // Save tasks to local storage
    localStorage.setItem("nova-tasks", JSON.stringify(tasks));
    
    // Calculate completion rate
    if (tasks.length > 0) {
      const completedCount = tasks.filter(task => task.completed).length;
      setCompletionRate(Math.round((completedCount / tasks.length) * 100));
    } else {
      setCompletionRate(0);
    }
  }, [tasks]);

  const addTask = () => {
    if (!newTaskTitle.trim()) {
      toast.error("Task title cannot be empty");
      return;
    }
    
    const newTask: Task = {
      id: Date.now().toString(),
      title: newTaskTitle,
      completed: false,
      date: new Date()
    };
    
    setTasks(prev => [...prev, newTask]);
    setNewTaskTitle("");
    toast.success("Task added successfully");
  };

  const toggleTaskCompletion = (id: string) => {
    setTasks(prev => 
      prev.map(task => 
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(task => task.id !== id));
    toast.success("Task deleted successfully");
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      addTask();
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", { 
      month: "short", 
      day: "numeric" 
    });
  };

  return (
    <div className="space-y-6 p-2 pb-20">
      <div className="flex items-center space-x-2">
        <Link to="/skills">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">To-Do List</h1>
      </div>

      <Separator />

      <div className="space-y-4">
        <div className="glass-morphism rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-medium">Task Completion</h2>
            <span>{completionRate}%</span>
          </div>
          <Progress value={completionRate} className="h-2" />
        </div>

        <div className="flex space-x-2">
          <Input 
            placeholder="Add a new task..."
            value={newTaskTitle}
            onChange={(e) => setNewTaskTitle(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-grow bg-black/30 border-gray-700"
          />
          <Button onClick={addTask}>
            <Plus className="h-5 w-5" />
          </Button>
        </div>

        <div className="space-y-2">
          {tasks.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <p>No tasks yet. Add some to get started!</p>
            </div>
          ) : (
            tasks.map(task => (
              <div 
                key={task.id}
                className={`glass-morphism rounded-lg p-3 flex items-center space-x-3 ${
                  task.completed ? "opacity-70" : ""
                }`}
              >
                <Checkbox 
                  checked={task.completed} 
                  onCheckedChange={() => toggleTaskCompletion(task.id)}
                  className="h-5 w-5"
                />
                <div className="flex-1">
                  <p className={task.completed ? "line-through text-gray-400" : ""}>
                    {task.title}
                  </p>
                  <div className="flex items-center text-xs text-gray-400 mt-1">
                    <Calendar className="h-3 w-3 mr-1" />
                    {formatDate(task.date)}
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => deleteTask(task.id)}
                  className="h-8 w-8 text-gray-400 hover:text-red-400"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Todo;
