
import React, { useState, useEffect, useRef } from "react";
import { ArrowLeft, Bot, Send, Download, Image } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";

// RapidAPI API key
const API_KEY = "ee5cb56915msh6a75b84b9a1a10ap1705e4jsn6fdda3541c85";
const API_HOST = "chatgpt-42.p.rapidapi.com";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  image?: string;
}

const CreativeAI = () => {
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { 
      role: "assistant", 
      content: "Hi there! I'm your AI image creator. Tell me what kind of image you want to generate, and I'll create it for you." 
    }
  ]);
  const [chatLoading, setChatLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const generateImage = async (prompt: string) => {
    try {
      setChatLoading(true);
      
      // Calculate dimensions (default to square)
      let width = 512;
      let height = 512;
      
      const options = {
        method: 'POST',
        headers: {
          'x-rapidapi-key': API_KEY,
          'x-rapidapi-host': API_HOST,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          text: prompt,
          width: width,
          height: height
        })
      };

      const response = await fetch('https://chatgpt-42.p.rapidapi.com/texttoimage', options);

      if (!response.ok) {
        throw new Error(`API request failed: ${response.statusText}`);
      }

      const data = await response.json();
      
      // Handle the API response correctly based on the network response
      // The API returns "generated_image" as the key
      if (data && data.generated_image) {
        return data.generated_image;
      } else {
        console.error("Unexpected API response:", data);
        throw new Error("No image URL returned from API");
      }
    } catch (error) {
      console.error("Image generation error:", error);
      toast.error("Failed to generate image");
      return null;
    }
  };

  const sendChatMessage = async () => {
    if (!chatInput.trim()) return;
    
    const userMessage = { role: "user" as const, content: chatInput };
    setChatMessages(prev => [...prev, userMessage]);
    setChatInput("");
    setChatLoading(true);
    
    try {
      // For the Image Creator, we'll assume all messages are requests to generate images
      const imageUrl = await generateImage(chatInput);
      
      if (imageUrl) {
        const assistantReply = { 
          role: "assistant" as const, 
          content: "Here's the image I created based on your request:",
          image: imageUrl
        };
        setChatMessages(prev => [...prev, assistantReply]);
        toast.success("Image generated successfully!");
      } else {
        const assistantReply = { 
          role: "assistant" as const, 
          content: "I'm sorry, I couldn't generate an image based on your request. Please try a different description."
        };
        setChatMessages(prev => [...prev, assistantReply]);
      }
    } catch (error) {
      console.error("Chat error:", error);
      setChatMessages(prev => [...prev, { 
        role: "assistant", 
        content: "I'm sorry, I encountered an error processing your request. Please try again later." 
      }]);
      toast.error("Failed to get response");
    } finally {
      setChatLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendChatMessage();
    }
  };

  const downloadImage = (url: string) => {
    const link = document.createElement("a");
    link.href = url;
    link.download = `nova-creative-${Date.now()}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success("Image downloaded");
  };

  return (
    <div className="space-y-6 p-2 pb-20 flex flex-col h-[calc(100vh-120px)]">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Link to="/skills">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Image Creator</h1>
        </div>
      </div>

      <Separator />

      <div className="glass-morphism rounded-lg p-4 flex flex-col flex-grow">
        <div className="flex-grow overflow-y-auto mb-4 space-y-4">
          {chatMessages.map((message, index) => (
            <div 
              key={index} 
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.role === 'user' 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-secondary text-secondary-foreground'
                }`}
              >
                <p className="whitespace-pre-wrap">{message.content}</p>
                {message.image && (
                  <div className="mt-2 relative group">
                    <img 
                      src={message.image} 
                      alt="Generated image"
                      className="w-full h-auto rounded-md"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center rounded-md transition-opacity">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => downloadImage(message.image!)}
                        className="bg-white/20 hover:bg-white/30"
                      >
                        <Download className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
          {chatLoading && (
            <div className="flex justify-start">
              <div className="max-w-[80%] rounded-lg p-3 bg-secondary text-secondary-foreground">
                <div className="flex space-x-2">
                  <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                  <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>
      
      <div className="sticky bottom-0 z-10 bg-black/30 p-2 rounded-lg">
        <div className="flex items-center space-x-2">
          <Input
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Describe the image you want to create..."
            className="bg-black/30"
            disabled={chatLoading}
          />
          <Button 
            onClick={sendChatMessage} 
            disabled={!chatInput.trim() || chatLoading}
            size="icon"
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CreativeAI;
