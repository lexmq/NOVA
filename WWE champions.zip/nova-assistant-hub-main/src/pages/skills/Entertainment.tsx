import React, { useState, useEffect } from "react";
import { ArrowLeft, Search, Star, Film, Tv, Award, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useOMDBService, MovieSearchResult } from "@/services/useOMDBService";

interface Movie {
  id: string;
  title: string;
  year: string;
  rating?: number;
  genre: string[];
  poster: string;
  description?: string;
  language?: string;
  imdbID?: string;
}

// Fallback demo movies in case API fails
const demoMovies: Movie[] = [
  {
    id: "1",
    title: "The Matrix",
    year: "1999",
    rating: 8.7,
    genre: ["Action", "Sci-Fi"],
    poster: "https://images.unsplash.com/photo-1639762681057-408e52192e55",
    description: "A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers."
  },
  {
    id: "2",
    title: "Inception",
    year: "2010",
    rating: 8.8,
    genre: ["Action", "Adventure", "Sci-Fi"],
    poster: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba",
    description: "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O."
  },
  {
    id: "3",
    title: "The Shawshank Redemption",
    year: "1994",
    rating: 9.3,
    genre: ["Drama"],
    poster: "https://images.unsplash.com/photo-1543536448-d209d2d13a1c",
    description: "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency."
  },
  {
    id: "4",
    title: "The Dark Knight",
    year: "2008",
    rating: 9.0,
    genre: ["Action", "Crime", "Drama"],
    poster: "https://images.unsplash.com/photo-1635805737707-575885ab0820",
    description: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice."
  },
  {
    id: "5",
    title: "Pulp Fiction",
    year: "1994",
    rating: 8.9,
    genre: ["Crime", "Drama"],
    poster: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0",
    description: "The lives of two mob hitmen, a boxer, a gangster and his wife, and a pair of diner bandits intertwine in four tales of violence and redemption."
  },
  {
    id: "6",
    title: "Forrest Gump",
    year: "1994",
    rating: 8.8,
    genre: ["Drama", "Romance"],
    poster: "https://images.unsplash.com/photo-1594909122845-11baa439b7bf",
    description: "The presidencies of Kennedy and Johnson, the Vietnam War, the Watergate scandal and other historical events unfold from the perspective of an Alabama man with an IQ of 75, whose only desire is to be reunited with his childhood sweetheart."
  }
];

// Fallback demo Hindi movies in case API fails
const demoHindiMovies: Movie[] = [
  {
    id: "h1",
    title: "3 Idiots",
    year: "2009",
    rating: 8.4,
    genre: ["Comedy", "Drama"],
    poster: "https://images.unsplash.com/photo-1586899028174-e7098604235b",
    description: "Two friends are searching for their long lost companion. They revisit their college days and recall the memories of their friend who inspired them to think differently, even as the rest of the world called them 'idiots'.",
    language: "Hindi"
  },
  {
    id: "h2",
    title: "Dangal",
    year: "2016",
    rating: 8.3,
    genre: ["Action", "Biography", "Drama"],
    poster: "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5",
    description: "Former wrestler Mahavir Singh Phogat and his two wrestler daughters struggle towards glory at the Commonwealth Games in the face of societal oppression.",
    language: "Hindi"
  },
  {
    id: "h3",
    title: "Lagaan",
    year: "2001",
    rating: 8.1,
    genre: ["Drama", "Musical", "Sport"],
    poster: "https://images.unsplash.com/photo-1568572933382-74d440642117",
    description: "The people of a small village in Victorian India stake their future on a game of cricket against their ruthless British rulers.",
    language: "Hindi"
  },
  {
    id: "h4",
    title: "PK",
    year: "2014",
    rating: 8.1,
    genre: ["Comedy", "Drama", "Sci-Fi"],
    poster: "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c",
    description: "An alien on Earth loses the only device he can use to communicate with his spaceship. His innocent nature and child-like questions force the country to evaluate the impact of religion on its people.",
    language: "Hindi"
  },
  {
    id: "h5",
    title: "Gangs of Wasseypur",
    year: "2012",
    rating: 8.2,
    genre: ["Action", "Crime", "Drama"],
    poster: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0",
    description: "A clash between Sultan and Shahid Khan leads to the expulsion of Khan from Wasseypur, and ignites a deadly blood feud spanning three generations.",
    language: "Hindi"
  },
  {
    id: "h6",
    title: "Gully Boy",
    year: "2019",
    rating: 8.0,
    genre: ["Drama", "Music"],
    poster: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4",
    description: "A coming-of-age story based on the lives of street rappers in Mumbai.",
    language: "Hindi"
  }
];

// Fallback demo TV shows in case API fails
const demoTVShows: Movie[] = [
  {
    id: "7",
    title: "Breaking Bad",
    year: "2008-2013",
    rating: 9.5,
    genre: ["Crime", "Drama", "Thriller"],
    poster: "https://images.unsplash.com/photo-1604326531570-2689ea7ae287",
    description: "A high school chemistry teacher diagnosed with inoperable lung cancer turns to manufacturing and selling methamphetamine in order to secure his family's future."
  },
  {
    id: "8",
    title: "Game of Thrones",
    year: "2011-2019",
    rating: 9.3,
    genre: ["Action", "Adventure", "Drama"],
    poster: "https://images.unsplash.com/photo-1571715268998-d6e79bed5fc9",
    description: "Nine noble families fight for control over the lands of Westeros, while an ancient enemy returns after being dormant for millennia."
  },
  {
    id: "9",
    title: "Stranger Things",
    year: "2016-",
    rating: 8.7,
    genre: ["Drama", "Fantasy", "Horror"],
    poster: "https://images.unsplash.com/photo-1626379953822-baec19c3accd",
    description: "When a young boy disappears, his mother, a police chief and his friends must confront terrifying supernatural forces in order to get him back."
  },
  {
    id: "h7",
    title: "Sacred Games",
    year: "2018-2019",
    rating: 8.6,
    genre: ["Action", "Crime", "Drama"],
    poster: "https://images.unsplash.com/photo-1582266255765-fa5cf1a1d501",
    description: "A link in their pasts leads an honest cop to a fugitive gang boss, whose cryptic warning spurs the officer on a quest to save Mumbai from cataclysm.",
    language: "Hindi"
  },
  {
    id: "h8",
    title: "Mirzapur",
    year: "2018-",
    rating: 8.4,
    genre: ["Action", "Crime", "Thriller"],
    poster: "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c",
    description: "A shocking incident at a wedding procession ignites a series of events entangling the lives of two families in the lawless city of Mirzapur.",
    language: "Hindi"
  }
];

const Entertainment = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("movies");
  const [filteredMovies, setFilteredMovies] = useState<Movie[]>([]);
  const [filteredTVShows, setFilteredTVShows] = useState<Movie[]>([]);
  const [selectedItem, setSelectedItem] = useState<Movie | null>(null);
  const [languageFilter, setLanguageFilter] = useState<string>("all");
  const { searchMovies, getMovieDetails, isLoading } = useOMDBService();
  const [page, setPage] = useState(1);
  const [totalResults, setTotalResults] = useState(0);
  
  // Initial load of movies
  useEffect(() => {
    loadMovies("popular", "movie");
    loadMovies("popular", "series");
  }, []);

  // Search when query changes
  useEffect(() => {
    if (searchQuery) {
      const delaySearch = setTimeout(() => {
        performSearch();
      }, 800);
      return () => clearTimeout(delaySearch);
    }
  }, [searchQuery, activeTab, languageFilter, page]);

  const loadMovies = async (query: string, type: string) => {
    try {
      const response = await searchMovies(query, type, undefined, 1);
      
      if (response.Response === "True" && response.Search) {
        const formattedMovies: Movie[] = response.Search.map(movie => ({
          id: movie.imdbID,
          imdbID: movie.imdbID,
          title: movie.Title,
          year: movie.Year,
          genre: [], // Will be populated when viewing details
          poster: movie.Poster !== "N/A" ? movie.Poster : "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=300",
          language: "English" // Default assumption, will be updated when details are fetched
        }));
        
        if (type === "movie") {
          setFilteredMovies(formattedMovies);
        } else {
          setFilteredTVShows(formattedMovies);
        }
        
        setTotalResults(parseInt(response.totalResults || "0"));
      } else {
        // Fallback to demo data if API fails
        if (type === "movie") {
          setFilteredMovies([...demoMovies, ...demoHindiMovies]);
        } else {
          setFilteredTVShows(demoTVShows);
        }
      }
    } catch (error) {
      console.error("Error loading movies:", error);
      // Fallback to demo data
      if (type === "movie") {
        setFilteredMovies([...demoMovies, ...demoHindiMovies]);
      } else {
        setFilteredTVShows(demoTVShows);
      }
    }
  };

  const performSearch = async () => {
    if (!searchQuery.trim()) {
      loadMovies("popular", activeTab === "movies" ? "movie" : "series");
      return;
    }

    try {
      const type = activeTab === "movies" ? "movie" : "series";
      const response = await searchMovies(searchQuery, type, undefined, page);
      
      if (response.Response === "True" && response.Search) {
        const formattedMovies: Movie[] = response.Search.map(movie => ({
          id: movie.imdbID,
          imdbID: movie.imdbID,
          title: movie.Title,
          year: movie.Year,
          genre: [],
          poster: movie.Poster !== "N/A" ? movie.Poster : "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=300"
        }));
        
        if (activeTab === "movies") {
          setFilteredMovies(formattedMovies);
        } else {
          setFilteredTVShows(formattedMovies);
        }
        
        setTotalResults(parseInt(response.totalResults || "0"));
      } else {
        if (activeTab === "movies") {
          setFilteredMovies([]);
        } else {
          setFilteredTVShows([]);
        }
        toast.info(response.Error || "No results found");
      }
    } catch (error) {
      console.error("Search error:", error);
      toast.error("Failed to search. Using demo data instead.");
      
      // Fallback to filtered demo data
      if (activeTab === "movies") {
        const filtered = [...demoMovies, ...demoHindiMovies].filter(
          movie => movie.title.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setFilteredMovies(filtered);
      } else {
        const filtered = demoTVShows.filter(
          show => show.title.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setFilteredTVShows(filtered);
      }
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1); // Reset to first page
    performSearch();
  };

  const showDetails = async (item: Movie) => {
    if (item.imdbID) {
      try {
        const details = await getMovieDetails(item.imdbID);
        if (details) {
          const enhancedItem: Movie = {
            ...item,
            genre: details.Genre.split(", "),
            description: details.Plot,
            language: details.Language,
            rating: parseFloat(details.imdbRating)
          };
          setSelectedItem(enhancedItem);
        } else {
          setSelectedItem(item);
        }
      } catch {
        setSelectedItem(item);
      }
    } else {
      setSelectedItem(item);
    }
  };

  return (
    <div className="space-y-6 p-2 pb-20">
      <div className="flex items-center space-x-2">
        <Link to="/skills">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Movies & TV</h1>
      </div>

      <Separator />

      <form onSubmit={handleSearch} className="relative">
        <Input
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search movies and TV shows..."
          className="bg-black/30 pl-10"
        />
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
      </form>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full">
          <TabsTrigger value="movies" className="flex-1">
            <Film className="h-4 w-4 mr-2" />
            Movies
          </TabsTrigger>
          <TabsTrigger value="tv" className="flex-1">
            <Tv className="h-4 w-4 mr-2" />
            TV Shows
          </TabsTrigger>
        </TabsList>
        
        <div className="my-3 flex justify-end">
          <Select value={languageFilter} onValueChange={setLanguageFilter}>
            <SelectTrigger className="w-[140px] bg-black/30">
              <SelectValue placeholder="Language" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Languages</SelectItem>
              <SelectItem value="english">English</SelectItem>
              <SelectItem value="hindi">Hindi</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <TabsContent value="movies" className="mt-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-10">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredMovies.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <p>No movies found matching your search.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {filteredMovies.map((movie) => (
                <div 
                  key={movie.id} 
                  className="glass-morphism rounded-lg overflow-hidden cursor-pointer"
                  onClick={() => showDetails(movie)}
                >
                  <div className="relative h-40">
                    <img 
                      src={movie.poster} 
                      alt={movie.title}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=300";
                      }}
                    />
                    {movie.rating && (
                      <div className="absolute top-2 right-2 bg-black/70 text-yellow-400 text-xs font-bold px-2 py-1 rounded-full flex items-center">
                        <Star className="h-3 w-3 mr-1 fill-yellow-400" />
                        {movie.rating}
                      </div>
                    )}
                    {movie.language && (
                      <div className="absolute top-2 left-2 bg-black/70 text-white text-xs font-medium px-2 py-1 rounded-full">
                        {movie.language}
                      </div>
                    )}
                  </div>
                  <div className="p-3">
                    <h3 className="font-medium truncate">{movie.title}</h3>
                    <div className="flex justify-between items-center mt-1">
                      <span className="text-xs text-gray-400">{movie.year}</span>
                      {movie.genre && movie.genre.length > 0 && (
                        <span className="text-xs text-gray-400">
                          {movie.genre.slice(0, 2).join(", ")}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {totalResults > 10 && (
            <div className="flex justify-center mt-8 space-x-2">
              <Button 
                variant="outline" 
                onClick={() => setPage(prev => Math.max(1, prev - 1))}
                disabled={page === 1}
              >
                Previous
              </Button>
              <Button variant="outline" disabled>
                Page {page}
              </Button>
              <Button 
                variant="outline"
                onClick={() => setPage(prev => prev + 1)}
                disabled={page * 10 >= totalResults}
              >
                Next
              </Button>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="tv" className="mt-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-10">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredTVShows.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <p>No TV shows found matching your search.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {filteredTVShows.map((show) => (
                <div 
                  key={show.id} 
                  className="glass-morphism rounded-lg overflow-hidden cursor-pointer"
                  onClick={() => showDetails(show)}
                >
                  <div className="relative h-40">
                    <img 
                      src={show.poster} 
                      alt={show.title}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=300";
                      }}
                    />
                    {show.rating && (
                      <div className="absolute top-2 right-2 bg-black/70 text-yellow-400 text-xs font-bold px-2 py-1 rounded-full flex items-center">
                        <Star className="h-3 w-3 mr-1 fill-yellow-400" />
                        {show.rating}
                      </div>
                    )}
                    {show.language && (
                      <div className="absolute top-2 left-2 bg-black/70 text-white text-xs font-medium px-2 py-1 rounded-full">
                        {show.language}
                      </div>
                    )}
                  </div>
                  <div className="p-3">
                    <h3 className="font-medium truncate">{show.title}</h3>
                    <div className="flex justify-between items-center mt-1">
                      <span className="text-xs text-gray-400">{show.year}</span>
                      {show.genre && show.genre.length > 0 && (
                        <span className="text-xs text-gray-400">
                          {show.genre.slice(0, 2).join(", ")}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {totalResults > 10 && (
            <div className="flex justify-center mt-8 space-x-2">
              <Button 
                variant="outline" 
                onClick={() => setPage(prev => Math.max(1, prev - 1))}
                disabled={page === 1}
              >
                Previous
              </Button>
              <Button variant="outline" disabled>
                Page {page}
              </Button>
              <Button 
                variant="outline"
                onClick={() => setPage(prev => prev + 1)}
                disabled={page * 10 >= totalResults}
              >
                Next
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {selectedItem && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <Card className="max-w-md w-full bg-black/90 border-gray-800">
            <div className="relative h-48">
              <img 
                src={selectedItem.poster} 
                alt={selectedItem.title}
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=300";
                }}
              />
              <Button 
                variant="ghost" 
                size="icon"
                className="absolute top-2 right-2 bg-black/50 hover:bg-black/70"
                onClick={() => setSelectedItem(null)}
              >
                ✕
              </Button>
              {selectedItem.rating && (
                <div className="absolute bottom-2 right-2 bg-black/70 text-yellow-400 text-sm font-bold px-2 py-1 rounded-full flex items-center">
                  <Star className="h-4 w-4 mr-1 fill-yellow-400" />
                  {selectedItem.rating}
                </div>
              )}
              {selectedItem.language && (
                <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs font-medium px-2 py-1 rounded-full">
                  {selectedItem.language}
                </div>
              )}
            </div>
            <CardContent className="pt-4">
              <div className="flex justify-between items-start mb-2">
                <h2 className="text-xl font-bold">{selectedItem.title}</h2>
                <span className="text-sm text-gray-400">{selectedItem.year}</span>
              </div>
              <div className="flex flex-wrap gap-2 mb-3">
                {selectedItem.genre.map((g, i) => (
                  <span 
                    key={i} 
                    className="text-xs bg-primary/20 text-primary px-2 py-1 rounded-full"
                  >
                    {g}
                  </span>
                ))}
              </div>
              <p className="text-gray-300 text-sm">{selectedItem.description || "No description available."}</p>
              <div className="mt-4 flex justify-end">
                <Button variant="default" onClick={() => {
                  setSelectedItem(null);
                  toast.success("Added to watchlist!");
                }}>
                  Add to Watchlist
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default Entertainment;
