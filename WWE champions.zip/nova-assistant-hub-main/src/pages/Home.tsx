import React, { useState, useEffect } from "react";
import { Mic, Brain, Calendar, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { useNavigate } from "react-router-dom";
import { useOpenAIService } from "@/services/useOpenAIService";

interface QuickAction {
  icon: React.ElementType;
  label: string;
  color: string;
  onClick: () => void;
}

// API Keys - These should be properly secured in a production application
const WEATHER_API_KEY = "233ef4ef019b36ca7ab3fc4503f873b2";
const STOCK_MARKET_API_KEY = "9KIEUIJOMULLJ39P";
const GOOGLE_MAPS_API_KEY = "AIzaSyBVrXHuwOWl8xXjBspYoF-KLKFgetW0Dbo";

// App URLs mapping
const APP_URLS: Record<string, string> = {
  // Social Media & Messaging
  "facebook": "https://www.facebook.com/",
  "twitter": "https://twitter.com/", 
  "x": "https://twitter.com/",
  "instagram": "https://www.instagram.com/",
  "whatsapp": "https://web.whatsapp.com/",
  "telegram": "https://telegram.org/",
  "discord": "https://discord.com/",
  "slack": "https://slack.com/",
  "snapchat": "https://www.snapchat.com/",
  "tiktok": "https://www.tiktok.com/",
  "reddit": "https://www.reddit.com/",
  "linkedin": "https://www.linkedin.com/",
  "signal": "https://signal.org/",
  "wechat": "https://www.wechat.com/",
  "messenger": "https://www.messenger.com/",
  
  // Productivity & Cloud Storage
  "google drive": "https://www.google.com/drive/",
  "dropbox": "https://www.dropbox.com/",
  "onedrive": "https://onedrive.live.com/",
  "evernote": "https://evernote.com/",
  "notion": "https://www.notion.so/",
  "trello": "https://trello.com/",
  "asana": "https://asana.com/",
  "google calendar": "https://calendar.google.com/",
  "outlook": "https://outlook.live.com/",
  "monday": "https://monday.com/",
  "clickup": "https://www.clickup.com/",
  
  // Entertainment & Media
  "youtube": "https://www.youtube.com/",
  "spotify": "https://www.spotify.com/",
  "netflix": "https://www.netflix.com/",
  "amazon prime": "https://www.primevideo.com/",
  "prime video": "https://www.primevideo.com/",
  "disney plus": "https://www.disneyplus.com/",
  "disney+": "https://www.disneyplus.com/",
  "apple music": "https://music.apple.com/",
  "soundcloud": "https://soundcloud.com/",
  "twitch": "https://www.twitch.tv/",
  "deezer": "https://www.deezer.com/",
  "pandora": "https://www.pandora.com/",
  "iheartradio": "https://www.iheart.com/",
  
  // Finance & Payments
  "paypal": "https://www.paypal.com/",
  "stripe": "https://stripe.com/",
  "google pay": "https://pay.google.com/",
  "apple pay": "https://www.apple.com/apple-pay/",
  "venmo": "https://venmo.com/",
  "cash app": "https://cash.app/",
  "wise": "https://wise.com/",
  "transferwise": "https://wise.com/",
  "western union": "https://www.westernunion.com/",
  "revolut": "https://www.revolut.com/",
  
  // AI & Search Engines
  "google": "https://www.google.com/",
  "bing": "https://www.bing.com/",
  "openai": "https://openai.com/",
  "chatgpt": "https://chat.openai.com/",
  "gemini": "https://gemini.google.com/",
  "bard": "https://gemini.google.com/",
  "ibm watson": "https://www.ibm.com/watson",
  "duckduckgo": "https://duckduckgo.com/",
  
  // Smart Home & IoT
  "alexa": "https://alexa.amazon.com/",
  "google home": "https://home.google.com/",
  "smartthings": "https://www.smartthings.com/",
  "homekit": "https://www.apple.com/ios/home/",
  "tuya": "https://www.tuya.com/",
  
  // E-commerce & Shopping
  "amazon": "https://www.amazon.com/",
  "ebay": "https://www.ebay.com/",
  "shopify": "https://www.shopify.com/",
  "walmart": "https://www.walmart.com/",
  "etsy": "https://www.etsy.com/",
  "aliexpress": "https://www.aliexpress.com/",
  
  // Travel & Navigation
  "google maps": "https://www.google.com/maps",
  "maps": "https://www.google.com/maps",
  "waze": "https://www.waze.com/",
  "uber": "https://www.uber.com/",
  "lyft": "https://www.lyft.com/",
  "airbnb": "https://www.airbnb.com/",
  "booking": "https://www.booking.com/",
  
  // Developer Tools & Cloud Platforms
  "github": "https://github.com/",
  "gitlab": "https://gitlab.com/",
  "bitbucket": "https://bitbucket.org/",
  "aws": "https://aws.amazon.com/",
  "google cloud": "https://cloud.google.com/",
  "azure": "https://azure.microsoft.com/",
  
  // Internal app navigation
  "chat": "/chat",
  "todo": "/skills/todo",
  "schedule": "/skills/todo",
  "movies": "/skills/entertainment",
  "entertainment": "/skills/entertainment"
};

const Home = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [greeting, setGreeting] = useState("Good morning");
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const { generateChatResponse } = useOpenAIService();

  // Initialize speech recognition if available
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);

  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      navigate('/settings/account');
    }
  }, [user, navigate]);

  useEffect(() => {
    // Set greeting based on time of day
    const hour = new Date().getHours();
    if (hour < 12) setGreeting("Good morning");
    else if (hour < 18) setGreeting("Good afternoon");
    else setGreeting("Good evening");
    
    // Initialize speech recognition
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognitionAPI) {
        const recognitionInstance = new SpeechRecognitionAPI();
        
        recognitionInstance.continuous = false;
        recognitionInstance.interimResults = false;
        recognitionInstance.lang = 'en-US';
        
        recognitionInstance.onresult = (event) => {
          const current = event.resultIndex;
          const transcriptText = event.results[current][0].transcript;
          setTranscript(transcriptText);
          handleVoiceCommand(transcriptText);
        };
        
        recognitionInstance.onend = () => {
          setIsListening(false);
        };
        
        recognitionInstance.onerror = (event) => {
          console.error('Speech recognition error', event.error);
          setIsListening(false);
          toast.error("Couldn't understand. Please try again.");
        };
        
        setRecognition(recognitionInstance);
      }
    }
  }, []);

  // Enhanced weather data function with better error handling and detailed response
  const fetchWeatherData = async (city = "London") => {
    try {
      setIsProcessing(true);
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${WEATHER_API_KEY}&units=metric`
      );
      
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error(`City "${city}" not found. Please try another location.`);
        }
        throw new Error(`Weather service error (${response.status}): ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Format date for response
      const now = new Date();
      const dateOptions: Intl.DateTimeFormatOptions = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      };
      const formattedDate = now.toLocaleDateString('en-US', dateOptions);
      
      // Build detailed weather info
      const weatherInfo = `Current weather for ${formattedDate} in ${data.name}, ${data.sys.country}: 
        ${data.weather[0].description}. 
        Temperature: ${Math.round(data.main.temp)}°C (${Math.round(data.main.temp * 9/5 + 32)}°F),
        feels like ${Math.round(data.main.feels_like)}°C.
        Humidity: ${data.main.humidity}%.
        Wind: ${Math.round(data.wind.speed * 3.6)} km/h.`;
        
      speak(weatherInfo);
    } catch (error) {
      console.error('Error fetching weather:', error);
      speak("I couldn't retrieve the weather information. " + (error instanceof Error ? error.message : "Please try again later."));
    } finally {
      setIsProcessing(false);
    }
  };

  // Enhanced stock market data function with better formatting and error handling
  const fetchStockData = async (symbol = "AAPL") => {
    try {
      setIsProcessing(true);
      const response = await fetch(
        `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${STOCK_MARKET_API_KEY}`
      );
      
      if (!response.ok) {
        throw new Error(`Stock service error (${response.status}): ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Check for API limit issues
      if (data.Note) {
        throw new Error("API call frequency limit reached. Please try again later.");
      }
      
      // Check if we have valid stock data
      if (data["Global Quote"] && Object.keys(data["Global Quote"]).length > 0) {
        const quote = data["Global Quote"];
        
        // Format the price and change values
        const price = parseFloat(quote["05. price"]).toFixed(2);
        const change = parseFloat(quote["09. change"]).toFixed(2);
        const changePercent = quote["10. change percent"].trim();
        
        // Determine if stock is up or down for verbal cue
        const direction = parseFloat(change) >= 0 ? "up" : "down";
        const absoluteChange = Math.abs(parseFloat(change));
        
        const stockInfo = `Current stock price for ${symbol}: $${price}. 
          The stock is ${direction} $${absoluteChange} (${changePercent}) today.
          Last updated: ${new Date().toLocaleTimeString()}.`;
          
        speak(stockInfo);
      } else {
        speak(`I couldn't find stock information for ${symbol}. Please check if the symbol is correct and try again.`);
      }
    } catch (error) {
      console.error('Error fetching stock data:', error);
      speak("I couldn't retrieve the stock market information. " + (error instanceof Error ? error.message : "Please try again later."));
    } finally {
      setIsProcessing(false);
    }
  };

  // Enhanced maps request handler with more options
  const handleMapsRequest = (destination?: string, mode?: string) => {
    let mapsUrl = `https://www.google.com/maps`;
    
    if (destination) {
      mapsUrl += `/search/${encodeURIComponent(destination)}`;
    }
    
    // Add travel mode if specified (driving, walking, bicycling, transit)
    if (mode && destination) {
      const travelMode = mode.toLowerCase();
      if (['driving', 'walking', 'bicycling', 'transit'].includes(travelMode)) {
        mapsUrl += `/dir///${encodeURIComponent(destination)}`;
        mapsUrl += `?travelmode=${travelMode}`;
      }
    }
    
    // Add API key
    mapsUrl += mapsUrl.includes('?') ? `&api=${GOOGLE_MAPS_API_KEY}` : `?api=${GOOGLE_MAPS_API_KEY}`;
    
    window.open(mapsUrl, '_blank');
    speak(`Opening Google Maps ${destination ? 'for ' + destination : ''} ${mode ? 'in ' + mode + ' mode' : ''}`);
  };

  // Enhanced voice command handler with better natural language processing
  const handleVoiceCommand = async (command: string) => {
    const lowerCommand = command.toLowerCase();
    console.log("Voice command received:", lowerCommand);
    setIsProcessing(true);
    
    // Handle stop command
    if (lowerCommand.includes('stop')) {
      speak("Stopping the current task");
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setIsProcessing(false);
      return;
    }
    
    // Enhanced app opening logic
    for (const [appName, url] of Object.entries(APP_URLS)) {
      const openPhrases = [`open ${appName}`, `launch ${appName}`, `go to ${appName}`, `show me ${appName}`];
      if (openPhrases.some(phrase => lowerCommand.includes(phrase))) {
        if (url.startsWith('http')) {
          window.open(url, '_blank');
          speak(`Opening ${appName} in a new tab`);
        } else {
          navigate(url);
          speak(`Opening ${appName}`);
        }
        setIsProcessing(false);
        return;
      }
    }
    
    // Enhanced weather command detection
    const weatherPatterns = [
      /weather(?:\s+in\s+([a-zA-Z\s]+))?/i,
      /what(?:'s| is) the weather(?:\s+in\s+([a-zA-Z\s]+))?/i,
      /how(?:'s| is) the weather(?:\s+in\s+([a-zA-Z\s]+))?/i
    ];
    
    for (const pattern of weatherPatterns) {
      const match = lowerCommand.match(pattern);
      if (match) {
        const city = match[1]?.trim() || "London";
        speak(`Getting current weather information for ${city}`);
        await fetchWeatherData(city);
        return;
      }
    }
    
    // Enhanced stock command detection
    const stockPatterns = [
      /(?:stock|stocks|share price)(?:\s+(?:for|of)\s+([a-zA-Z]+))/i,
      /how(?:'s| is) ([a-zA-Z]+) (?:stock|performing)/i,
      /([a-zA-Z]+) share price/i
    ];
    
    for (const pattern of stockPatterns) {
      const match = lowerCommand.match(pattern);
      if (match) {
        const symbol = match[1]?.trim().toUpperCase() || "AAPL";
        speak(`Checking latest stock information for ${symbol}`);
        await fetchStockData(symbol);
        return;
      }
    }
    
    // Enhanced maps command detection
    const directionsPattern = /(?:map|maps|directions|navigate)(?: to| for)? ([a-zA-Z\s]+)(?:\s+(?:by|using|with)\s+([a-zA-Z]+))?/i;
    const directionsMatch = lowerCommand.match(directionsPattern);
    
    if (directionsMatch || lowerCommand.includes('map') || lowerCommand.includes('directions')) {
      let destination = "";
      let mode = "";
      
      if (directionsMatch) {
        destination = directionsMatch[1]?.trim() || "";
        mode = directionsMatch[2]?.trim() || "";
      }
      
      handleMapsRequest(destination, mode);
      setIsProcessing(false);
      return;
    }
    
    // For all other commands, use OpenAI
    try {
      const messages = [
        {
          role: 'system' as const,
          content: 'You are Nova, a helpful virtual assistant. Provide concise and accurate responses.'
        },
        {
          role: 'user' as const,
          content: command
        }
      ];
      const response = await generateChatResponse(messages);
      speak(response);
    } catch (error) {
      console.error("Error processing with OpenAI:", error);
      speak("I'm having trouble connecting right now. Please try again later.");
    } finally {
      setIsProcessing(false);
    }
  };

  const toggleListening = () => {
    if (!recognition) {
      toast.error("Speech recognition is not supported in this browser");
      return;
    }
    
    if (isListening) {
      recognition.stop();
    } else {
      setIsListening(true);
      recognition.start();
      toast.info("Listening... Say something like 'open YouTube' or ask a question");
    }
  };

  // Enhanced speak function with better voice selection
  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      // Cancel any ongoing speech
      window.speechSynthesis.cancel();
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1;
      utterance.pitch = 0.9;
      utterance.volume = 1;
      
      // Get all available voices and ensure they're loaded
      let voices = window.speechSynthesis.getVoices();
      
      // If voices aren't loaded yet, wait for them
      if (voices.length === 0) {
        window.speechSynthesis.onvoiceschanged = () => {
          voices = window.speechSynthesis.getVoices();
          setVoice();
        };
      } else {
        setVoice();
      }
      
      function setVoice() {
        console.log("Available voices:", voices.map(v => `${v.name} (${v.lang})`));
        
        // Try to find a good quality male English voice
        const preferredVoices = [
          'Google UK English Male',
          'Microsoft David',
          'Google US English Male',
          'Daniel',
          'Thomas',
          'James'
        ];
        
        // Look for one of our preferred voices
        const selectedVoice = voices.find(voice => 
          preferredVoices.some(name => voice.name.includes(name)) && 
          voice.lang.startsWith('en')
        );
        
        // If we found a preferred voice, use it
        if (selectedVoice) {
          console.log(`Using voice: ${selectedVoice.name} (${selectedVoice.lang})`);
          utterance.voice = selectedVoice;
        } else {
          // Otherwise, try to find any English male voice
          const englishVoice = voices.find(voice => 
            voice.lang.startsWith('en') && 
            (voice.name.toLowerCase().includes('male') || 
             !voice.name.toLowerCase().includes('female'))
          );
          
          if (englishVoice) {
            console.log(`Using fallback voice: ${englishVoice.name} (${englishVoice.lang})`);
            utterance.voice = englishVoice;
          } else {
            console.log("No suitable voice found, using default voice");
          }
        }
        
        window.speechSynthesis.speak(utterance);
      }
    } else {
      console.error("Speech synthesis not supported");
    }
  };

  const quickActions: QuickAction[] = [
    {
      icon: Brain,
      label: "Ask AI",
      color: "bg-red-400",
      onClick: () => navigate("/chat")
    },
    {
      icon: Calendar,
      label: "Schedule",
      color: "bg-blue-400",
      onClick: () => navigate("/skills/todo")
    },
    {
      icon: Globe,
      label: "Smart Home",
      color: "bg-green-400",
      onClick: () => toast.info("Smart Home feature coming soon!")
    }
  ];

  return (
    <div className="flex flex-col h-full pt-10">
      <div className="flex flex-col space-y-1">
        <span className="text-gray-400 text-2xl">{greeting}</span>
        <h1 className="text-white text-5xl font-bold">{user ? user.name : 'Guest'}</h1>
      </div>
      
      <div className="flex justify-between mt-16 mb-20">
        {quickActions.map((action, index) => (
          <button 
            key={index}
            onClick={action.onClick}
            className="flex flex-col items-center"
          >
            <div className={`${action.color} rounded-full w-16 h-16 flex items-center justify-center mb-2`}>
              <action.icon className="w-7 h-7 text-white" />
            </div>
            <span className="text-white text-sm">{action.label}</span>
          </button>
        ))}
      </div>
      
      <div className="mt-auto">
        <div className="neo-blur rounded-xl p-4 flex items-center">
          <Button
            onClick={toggleListening}
            className={`rounded-full w-16 h-16 flex items-center justify-center ${isListening ? "bg-red-600 hover:bg-red-700" : "bg-primary hover:bg-primary/90"}`}
          >
            <Mic className="w-8 h-8 text-white" />
          </Button>
          <span className="ml-4 text-lg text-gray-300">
            {isListening ? "Listening..." : (isProcessing ? "Processing..." : "Tap to speak")}
          </span>
        </div>
      </div>
    </div>
  );
};

export default Home;
