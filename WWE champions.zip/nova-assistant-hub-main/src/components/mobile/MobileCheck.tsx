
import React, { useEffect, useState } from "react";
import { toast } from "sonner";
import { useIsMobile } from "@/hooks/use-mobile";
import { Platform } from "react-native";

const MobileCheck: React.FC = () => {
  const [isPWA, setIsPWA] = useState(false);
  const isMobile = useIsMobile();

  useEffect(() => {
    // Skip this check in native environments
    if (Platform.OS !== 'web') {
      return;
    }
    
    // Check if the app is being run as a PWA
    const isPWAMode = 'standalone' in window.navigator || 
      (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches);
    
    setIsPWA(isPWAMode);
    
    // Detect if mobile device
    const isMobileDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
      navigator.userAgent
    );

    // Show welcome toast when app is launched as PWA on mobile
    if (isPWAMode && isMobileDevice) {
      toast.success("Welcome to Nova Assistant Mobile!");
    } else if (isMobile) {
      // For first-time visitors on mobile browsers
      const hasSeenMobileBanner = localStorage.getItem('seen_mobile_banner');
      if (!hasSeenMobileBanner) {
        setTimeout(() => {
          toast("Add to Home Screen for the full mobile experience", {
            duration: 5000,
            action: {
              label: "Got it",
              onClick: () => localStorage.setItem('seen_mobile_banner', 'true'),
            },
          });
        }, 2000);
      }
    }
  }, [isMobile]);

  return null; // This component doesn't render anything
};

export default MobileCheck;
