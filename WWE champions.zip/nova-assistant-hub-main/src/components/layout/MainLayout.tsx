
import React, { useEffect } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import BottomNav from "./BottomNav";
import { useAuth } from "@/context/AuthContext";

const MainLayout = () => {
  const { isLoggedIn } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // If not logged in, redirect to account page
    if (!isLoggedIn) {
      navigate("/settings/account");
    }
  }, [isLoggedIn, navigate]);

  return (
    <div className="flex flex-col min-h-screen bg-black">
      <main className="flex-1 p-4 pb-20 overflow-y-auto">
        <Outlet />
      </main>
      <BottomNav />
    </div>
  );
};

export default MainLayout;
