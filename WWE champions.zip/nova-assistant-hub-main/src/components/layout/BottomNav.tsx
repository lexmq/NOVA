
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Home, MessageSquare, Brain, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { 
    icon: Home, 
    label: "Home", 
    path: "/" 
  },
  { 
    icon: MessageSquare, 
    label: "Chat", 
    path: "/chat" 
  },
  { 
    icon: Brain, 
    label: "Skills", 
    path: "/skills" 
  },
  { 
    icon: Settings, 
    label: "Settings", 
    path: "/settings" 
  },
];

const BottomNav = () => {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-900 py-2 px-4">
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link 
              key={item.path} 
              to={item.path}
              className="flex flex-col items-center"
            >
              <item.icon 
                className={cn(
                  "w-6 h-6", 
                  isActive ? "text-primary" : "text-gray-500"
                )} 
              />
              <span className={cn(
                "text-xs mt-1",
                isActive ? "text-primary" : "text-gray-500"
              )}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
