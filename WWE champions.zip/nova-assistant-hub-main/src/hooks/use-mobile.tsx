
import * as React from "react"
import { Platform, Dimensions } from "react-native"

const MOBILE_BREAKPOINT = 768

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(undefined)

  React.useEffect(() => {
    // For native platforms, use the platform check
    if (Platform.OS !== 'web') {
      setIsMobile(true)
      return
    }
    
    // For web, use the media query
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    }
    
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`)
    mql.addEventListener("change", checkIfMobile)
    checkIfMobile()
    
    return () => mql.removeEventListener("change", checkIfMobile)
  }, [])

  return !!isMobile
}
