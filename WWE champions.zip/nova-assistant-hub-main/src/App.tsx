
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import NotFound from "./pages/NotFound";
import MainLayout from "./components/layout/MainLayout";
import Skills from "./pages/Skills";
import Chat from "./pages/Chat";
import Settings from "./pages/Settings";
import Account from "./pages/settings/Account";
import Notifications from "./pages/settings/Notifications";
import Help from "./pages/settings/Help";
import Todo from "./pages/skills/Todo";
import Translator from "./pages/skills/Translator";
import CreativeAI from "./pages/skills/CreativeAI";
import Entertainment from "./pages/skills/Entertainment";
import { AuthProvider } from "./context/AuthContext";
import MobileCheck from "./components/mobile/MobileCheck";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <MobileCheck />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route element={<MainLayout />}>
              <Route path="/" element={<Home />} />
              <Route path="/chat" element={<Chat />} />
              <Route path="/skills" element={<Skills />} />
              <Route path="/settings" element={<Settings />} />
              
              {/* Settings Sub-routes */}
              <Route path="/settings/account" element={<Account />} />
              <Route path="/settings/notifications" element={<Notifications />} />
              <Route path="/settings/help" element={<Help />} />
              
              {/* Skills Sub-routes */}
              <Route path="/skills/todo" element={<Todo />} />
              <Route path="/skills/translator" element={<Translator />} />
              <Route path="/skills/creative-ai" element={<CreativeAI />} />
              <Route path="/skills/entertainment" element={<Entertainment />} />
            </Route>
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
