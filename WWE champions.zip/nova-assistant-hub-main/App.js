
import App from './src/App';

// This file is the entry point for Expo
export default App;
